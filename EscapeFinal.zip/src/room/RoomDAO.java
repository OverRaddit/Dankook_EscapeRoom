package room;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class RoomDAO {
	private Connection conn;
	private ResultSet rs;
	
	public RoomDAO() {
		
		try {
			String dbURL = "jdbc:mysql://localhost:3306/BBS?characterEncoding=UTF-8&serverTimezone=UTC";
			String dbID ="root";
			String dbPassword="1234";
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL,dbID,dbPassword);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<Room> getList(){
		String SQL="SELECT * FROM Room ORDER BY id";
		ArrayList<Room> list = new ArrayList<Room>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Room room= new Room();
				room.setId(rs.getInt(1));
				room.setBranch(rs.getString(2));
				room.setName(rs.getString(3));
				room.setLevel(rs.getInt(4));
				room.setTimelimit(rs.getInt(5));
				room.setType(rs.getInt(6));
				room.setActivity(rs.getInt(7));
				room.setRecompeople(rs.getInt(8));
				list.add(room);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public ArrayList<Room> getList(String branch, String name){
		String SQL=" SELECT * FROM Room WHERE branch=? AND name=?";
		ArrayList<Room> list = new ArrayList<Room>();
		/*
		if(branch==null) {
			SQL=" SELECT * FROM Room WHERE name=?";
		} else if(name==null) {
			SQL=" SELECT * FROM Room WHERE branch=?";
		} else if(branch==null & name==null) {
			SQL=" SELECT * FROM Room";}
		*/
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1,branch);
			pstmt.setString(2,name);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Room room= new Room();
				room.setId(rs.getInt(1));
				room.setBranch(rs.getString(2));
				room.setName(rs.getString(3));
				room.setLevel(rs.getInt(4));
				room.setTimelimit(rs.getInt(5));
				room.setType(rs.getInt(6));
				room.setActivity(rs.getInt(7));
				room.setRecompeople(rs.getInt(8));
				list.add(room);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public ArrayList<Room> getListbyBranch(String branch){
		String SQL="SELECT * FROM Room WHERE branch=? ORDER BY id";
		ArrayList<Room> list = new ArrayList<Room>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1,branch);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Room room= new Room();
				room.setId(rs.getInt(1));
				room.setBranch(rs.getString(2));
				room.setName(rs.getString(3));
				room.setLevel(rs.getInt(4));
				room.setTimelimit(rs.getInt(5));
				room.setType(rs.getInt(6));
				room.setActivity(rs.getInt(7));
				room.setRecompeople(rs.getInt(8));
				list.add(room);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public Room getListbyId(int id){
		String SQL="SELECT * FROM Room WHERE id=?";
		Room room= new Room();
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				room.setId(rs.getInt(1));
				room.setBranch(rs.getString(2));
				room.setName(rs.getString(3));
				room.setLevel(rs.getInt(4));
				room.setTimelimit(rs.getInt(5));
				room.setType(rs.getInt(6));
				room.setActivity(rs.getInt(7));
				room.setRecompeople(rs.getInt(8));
				return room;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return room;
	}
	
	
	
}



