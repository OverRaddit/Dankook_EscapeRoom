package room;
import java.util.*;

public class Room {
	private String branch;
	private String name;
	private int level;
	private int timelimit;
	private int type;
		// 1=�ڹ��� 2=��ġ 3=ȥ��
	private int activity;
		// 1=���� 2=���� 3=����
	private int recompeople;
	private int id;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getTimelimit() {
		return timelimit;
	}
	public void setTimelimit(int timelimit) {
		this.timelimit = timelimit;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getActivity() {
		return activity;
	}
	public void setActivity(int activity) {
		this.activity = activity;
	}
	public int getRecompeople() {
		return recompeople;
	}
	public void setRecompeople(int recompeople) {
		this.recompeople = recompeople;
	}
	
	public String levelStar() {
		if(level == 1) return "�ڡ١١١�";
		else if(level == 2) return "�ڡڡ١١�";
		else if(level == 3) return "�ڡڡڡ١�";
		else if(level == 4) return "�ڡڡڡڡ�";
		else if(level == 5) return "�ڡڡڡڡ�";
		else return "";		
	}

	public String typePrint(){
		if(type == 1) return "�ڹ���";
		else if(type == 2) return "��ġ";
		else if(type == 3) return "ȥ��";
		else return "";
	}

	public String activityPrint(){
		if(activity == 1) return "����";
		else if(activity == 2) return "����";
		else if(activity == 3) return "����";
		else return "";
	}
	
};