package reservation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bbs.Bbs;

public class ResDAO {
	private Connection conn;
	private ResultSet rs;
	
	public ResDAO() {
		
		try {
			String dbURL = "jdbc:mysql://localhost:3306/BBS?characterEncoding=UTF-8&serverTimezone=UTC";
			String dbID ="root";
			String dbPassword="1234";
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL,dbID,dbPassword);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public String getDate() {
		String SQL=" SELECT NOW()";
		try {
			PreparedStatement pstmt =conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	
	//�Ϸ�
	public int getNext() {
		String SQL=" SELECT ID FROM reservation ORDER BY ID DESC";
		try {
			PreparedStatement pstmt =conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1)+1;
			}
			return 1;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -1;	
	}
	
	//�Ϸ�
	public int write(int id,int rid, String resdate, String time,int resavailable,String user,int status) {
		String SQL="INSERT INTO reservation VALUES(?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt =conn.prepareStatement(SQL);
			pstmt.setInt(1, id);
			pstmt.setInt(2, rid);
			pstmt.setString(3, resdate);
			pstmt.setString(4, time);
			pstmt.setInt(5, resavailable);
			pstmt.setString(6, user);
			pstmt.setInt(7, status);
			return pstmt.executeUpdate();
			}catch(Exception e) {
			e.printStackTrace();
		}
		return -1;	// DB����
	}
	
	// delete ���Ⱑ ��Ƴ�...
	public int delete(int number) throws SQLException {
		PreparedStatement pstmt = null;
		try {
			String sql = "DELETE FROM reservation WHERE id= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, number);
			return pstmt.executeUpdate();
		} finally {
			if (pstmt != null) {
				pstmt.close();
				return -1;
			}
		}
	}
	//delete�����Ͽ� confirm����� => ����id���� �ش��ϴ� ��ü�� status���� ����
	public int confirm(int number) throws SQLException {
		PreparedStatement pstmt = null;
		try {
			String sql = "UPDATE reservation SET status = -1 WHERE id= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, number);
			return pstmt.executeUpdate();
		} finally {
			if (pstmt != null) {
				pstmt.close();
				return -1;
			}
		}
	}
	
	//�Ϸ�
	public ArrayList<Res> getListbyuser(String user){
		String SQL=" SELECT * FROM reservation WHERE user= ? AND available>0 ORDER BY ID DESC";
		ArrayList<Res> list = new ArrayList<Res>();
		try {
			PreparedStatement pstmt =conn.prepareStatement(SQL);
			pstmt.setString(1,user);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Res res= new Res();
				res.setId(rs.getInt(1));
				res.setRid(rs.getInt(2));
				res.setResdate(rs.getString(3));
				res.setTime(rs.getString(4));
				res.setResavailable(rs.getInt(5));
				res.setUser(rs.getString(6));
				res.setStatus(rs.getInt(7));
				list.add(res);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	//���Լ��� ��� ����ϴ°���?
	public ArrayList<Res> getListAll(String user){
		String SQL=" SELECT * FROM reservation WHERE user= ? AND Available>0 ORDER BY bbsID DESC";
		ArrayList<Res> list = new ArrayList<Res>();
		try {
			PreparedStatement pstmt =conn.prepareStatement(SQL);
			pstmt.setString(1,user);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Res res= new Res();
				res.setId(rs.getInt(1));
				res.setRid(rs.getInt(2));
				res.setResdate(rs.getString(3));
				res.setTime(rs.getString(4));
				res.setResavailable(rs.getInt(5));
				res.setUser(rs.getString(6));
				res.setStatus(rs.getInt(7));
				list.add(res);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	//������ �����ϰ������� Ȥ�ø��� �׳ɵ�. Ȯ���ϰ� �����Լ��� ��������.
	public ArrayList<Res> getListAll(){
		String SQL=" SELECT * FROM reservation ORDER BY ID DESC";
		ArrayList<Res> list = new ArrayList<Res>();
		try {
			PreparedStatement pstmt =conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Res res= new Res();
				res.setId(rs.getInt(1));
				res.setRid(rs.getInt(2));
				res.setResdate(rs.getString(3));
				res.setTime(rs.getString(4));
				res.setResavailable(rs.getInt(5));
				res.setUser(rs.getString(6));
				res.setStatus(rs.getInt(7));
				list.add(res);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public ArrayList<Bbs> getList(int pageNumber){
		String SQL=" SELECT * FROM reservation WHERE bbsID < ? AND bbsAvailable=1 ORDER BY bbsID DESC LIMIT 10";
		ArrayList<Bbs> list = new ArrayList<Bbs>();
		try {
			PreparedStatement pstmt =conn.prepareStatement(SQL);
			pstmt.setInt(1,getNext()-10*(pageNumber-1));
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Bbs bbs= new Bbs();
				bbs.setBbsID(rs.getInt(1));
				bbs.setBbsTitle(rs.getString(2));
				bbs.setUserID(rs.getString(3));
				bbs.setBbsDate(rs.getString(4));
				bbs.setBbsContent(rs.getString(5));
				bbs.setBbsAvailable(rs.getInt(6));
				list.add(bbs);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public boolean nextpage(int pageNumber){
		String SQL=" SELECT * FROM reservation WHERE bbsID < ? AND bbsAvailable=1 ORDER BY bbsID DESC LIMIT 10";
		try {
			PreparedStatement pstmt =conn.prepareStatement(SQL);
			pstmt.setInt(1,getNext()-10*(pageNumber-1));
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	
	
	public Res getResbyTime(String time,String date){
	      String SQL=" SELECT * FROM reservation WHERE time=? AND reservationdate=?";
	      Res res= new Res();
	      try {
	         PreparedStatement pstmt =conn.prepareStatement(SQL);
	         pstmt.setString(1, time+":00");
	         pstmt.setString(2, date);
	         rs = pstmt.executeQuery();
	         while(rs.next()) {
	            res.setId(rs.getInt(1));
	            res.setRid(rs.getInt(2));
	            res.setResdate(rs.getString(3));
	            res.setTime(rs.getString(4));
	            res.setResavailable(rs.getInt(5));
	            res.setUser(rs.getString(6));
	            res.setStatus(rs.getInt(7));
	            return res;
	         }
	      }catch(Exception e) {
	         e.printStackTrace();
	      }
	      return res;
	   }
	
	
	
}



