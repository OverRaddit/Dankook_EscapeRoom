package bbs;

public class Bbs {
	private int bbsID;
	private String bbsTitle;
	private String userID;
	private String bbsDate;
	private String bbsContent;
	private int bbsAvailable;// 0�̸� ������ ��, 1�̸� �Ϲ� ��, 2�� ������
	private int bbsRid;
	private int bbsRating;
	
	// getters & setters
	public int getBbsID() {
		return bbsID;
	}
	public void setBbsID(int bbsID) {
		this.bbsID = bbsID;
	}
	public String getBbsTitle() {
		return bbsTitle;
	}
	public void setBbsTitle(String bbsTitle) {
		this.bbsTitle = bbsTitle;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getBbsDate() {
		return bbsDate;
	}
	public void setBbsDate(String bbsDate) {
		this.bbsDate = bbsDate;
	}
	public String getBbsContent() {
		return bbsContent;
	}
	public void setBbsContent(String bbsContent) {
		this.bbsContent = bbsContent;
	}
	public int getBbsAvailable() {
		return bbsAvailable;
	}
	public void setBbsAvailable(int bbsAvailable) {
		this.bbsAvailable = bbsAvailable;
	}
	public int getBbsRid() {
		return bbsRid;
	}
	public void setBbsRid(int rid) {
		this.bbsRid = rid;
	}
	public int getBbsRating() {
		return bbsRating;
	}
	public void setBbsRating(int bbsRating) {
		this.bbsRating = bbsRating;
	}
	
	public String ratingStar() {
		if(bbsRating == 1) return "�ڡ١١١�";
		else if(bbsRating == 2) return "�ڡڡ١١�";
		else if(bbsRating == 3) return "�ڡڡڡ١�";
		else if(bbsRating == 4) return "�ڡڡڡڡ�";
		else if(bbsRating == 5) return "�ڡڡڡڡ�";
		else return "";		
	}
}
